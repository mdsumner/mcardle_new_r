void init_rand(unsigned long long seed);
double unif_rand();
unsigned unif_rand_u32();
double norm_rand();
double rnorm(double mu, double sigma);
